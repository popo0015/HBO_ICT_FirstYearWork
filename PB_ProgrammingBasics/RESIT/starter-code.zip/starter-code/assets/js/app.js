/**
 * This is the entire roller coaster log. It calls `fetchData()`
 * to mimic the fetching of remote data.
 * 
 * If you want to play around with the size of the array, see the `log.js` file 
 */
const log = fetchData();

// Call the `onLoad` function on the load event (when the DOM is ready). 
window.addEventListener('load', function() {
  //TODO initialize the application here

});

//TODO add other code here
